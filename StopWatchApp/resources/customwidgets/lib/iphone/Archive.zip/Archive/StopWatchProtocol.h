//
//  StopWatchProtocol.h
//  VMAppWithKonylib
//
//  Created by Kony Student on 10/7/14.
//
//

#import <Foundation/Foundation.h>

@protocol StopWatchProtocol <NSObject>

- (void) onClick;

@end
