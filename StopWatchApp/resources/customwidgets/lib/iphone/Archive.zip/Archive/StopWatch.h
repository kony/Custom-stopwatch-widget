//
//  StopWatch.h
//  VMAppWithKonylib
//
//  Created by Kony Student on 9/12/14.
//
//

#import "CWIWidget.h"
#import "KonyCWIEnvironment.h"

@interface StopWatch : UIControl <CWIWidget>

@property (nonatomic, strong) NSMutableArray *textColor,*bgColor,*fgCircleColor,*bgCircleColor;
@property int textSize;
@property float bgTransparancy;
@property (nonatomic, strong) KonyCWIEnvironment* konyEnv;
@property (nonatomic,strong) id stopWatchProtocol;

- (void)onTap;
-(NSString *)stopWatch;
-(void)startWatch;

@end
