//
//  StopWatch.m
//  VMAppWithKonylib
//
//  Created by Kony Student on 9/12/14.
//
//

#import "StopWatch.h"

@implementation StopWatch
{
    UILabel *stopWatchLabel;
    NSMutableAttributedString *labelText;
    CAAnimation *animationViewPosition;
    NSTimer *timer;
    int currentMinutes,currentSeconds,currentHours,radius;
    BOOL timerStop,foreGroundAnimationStop;
    CAShapeLayer *blackCircle;
    CAShapeLayer *grayCircle;
    CABasicAnimation *blackCircleAnimation;
}

- (void)animationDidStart:(CAAnimation *)anim{}

- (void)animationDidStop:(CAAnimation *)animation finished:(BOOL)finished
{
    [blackCircle removeFromSuperlayer];
    [grayCircle removeFromSuperlayer];
    if(foreGroundAnimationStop == false)
    {
        foreGroundAnimationStop = true;
    }
    else
    {
        [timer invalidate];
        timer = nil;
        [self resetTimer:false];
    }
        
}

-(NSString *)stopWatch
{
    if(currentHours == 0 && currentMinutes == 0 && currentSeconds == 0)
    {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Timer didn't start yet" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
        [alert show];        
    }
    else if (!timerStop)
    {
        foreGroundAnimationStop = false;
        [blackCircle removeAllAnimations];
        [stopWatchLabel setHidden:true];
        [self setHidden:true];
        [timer invalidate];
        timer = nil;
        timerStop = true;
    }
    else
    {
        NSLog(@"Timer Stopped already");
    }
    return [NSString stringWithFormat:@"%02d%@%02d%@%02d",currentHours,@":",currentMinutes,@":",currentSeconds];

}

-(void)startTimer
{
    timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(onTimer) userInfo:nil repeats:YES];
}

-(void)onTimer
{
    if(currentSeconds == 59)
    {
        if (currentMinutes ==59)
        {
            currentHours++;
            if (currentHours == 100)
            {
                [self stopWatch];
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Maximum time reached" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
                [alert show];
            }
            currentSeconds = 0;
            currentMinutes = 0;
        }
        else
        {
            currentMinutes++;
            currentSeconds = 0;
        }
    }
    else
    {
        currentSeconds++;
    }
    labelText = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%02d%@%02d%@%02d",currentHours,@":",currentMinutes,@":",currentSeconds]];
    [labelText addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue-UltraLight" size:_textSize] range:NSMakeRange(0,5)];
    [labelText addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue-UltraLight" size:(_textSize-10)] range:NSMakeRange(5, 3)];
    stopWatchLabel.attributedText = labelText;
}

-(void)startWatch
{
    if(timerStop == false)
    {
        NSLog(@"Timer running already");
    }
    else
    {
        [self displayCircles:true];
        currentHours = 0;
        currentMinutes = 0;
        currentSeconds = 0;
        timerStop = false;
        stopWatchLabel.textColor = [UIColor colorWithRed:([[_textColor objectAtIndex:0]intValue]/255.f) green:([[_textColor objectAtIndex:1]intValue]/255.f) blue:([[_textColor objectAtIndex:2]intValue]/255.f) alpha:1.0f];
        stopWatchLabel.backgroundColor = [UIColor clearColor];
        [stopWatchLabel setHidden:false];
        [self setHidden:false];
        [self startTimer];
    }
    
}

- (void)displayCircles: (BOOL)rotation
{
    radius = 70;
    
    grayCircle = [CAShapeLayer layer];
    grayCircle.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(80, 10, 2.0*radius, 2.0*radius) cornerRadius:radius].CGPath;
    grayCircle.fillColor = [UIColor clearColor].CGColor;
    CGColorRef myColor = [UIColor colorWithRed:([[_bgCircleColor objectAtIndex:0]intValue]/255.f) green:([[_bgCircleColor objectAtIndex:1]intValue]/255.f) blue:([[_bgCircleColor objectAtIndex:2]intValue]/255.f) alpha:1.0f].CGColor;
    [grayCircle setStrokeColor:myColor];
    grayCircle.strokeColor = [UIColor colorWithRed:([[_bgCircleColor objectAtIndex:0]intValue]/255.f) green:([[_bgCircleColor objectAtIndex:1]intValue]/255.f) blue:([[_bgCircleColor objectAtIndex:2]intValue]/255.f) alpha:1.0f].CGColor;
    grayCircle.lineWidth = 10;
    [self.layer addSublayer:grayCircle];
    
    blackCircle = [CAShapeLayer layer];
    blackCircle.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(80,10, 2.0*radius, 2.0*radius) cornerRadius:radius].CGPath;
    blackCircle.fillColor = [UIColor clearColor].CGColor;
    blackCircle.strokeColor = [UIColor colorWithRed:([[_fgCircleColor objectAtIndex:0]intValue]/255.f) green:([[_fgCircleColor objectAtIndex:1]intValue]/255.f) blue:([[_fgCircleColor objectAtIndex:2]intValue]/255.f) alpha:1.0f].CGColor;
    blackCircle.lineWidth = 10;
    [self.layer addSublayer:blackCircle];
    
    if (rotation)
    {
        blackCircleAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
        blackCircleAnimation.delegate = self;
        blackCircleAnimation.duration            = 60.0;
        blackCircleAnimation.repeatCount         = 6000-(currentMinutes+(currentHours*60));
        blackCircleAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
        blackCircleAnimation.toValue   = [NSNumber numberWithFloat:1.0f];
        [blackCircleAnimation setValue:@"AnimationValue" forKey:@"AnimationKey"];
        [blackCircle addAnimation:blackCircleAnimation forKey:@"BlackCircleAnimation"];
    }
    
}
- (void)displayText:(BOOL)initialize
{
    if (initialize)
    {
         stopWatchLabel = [[UILabel alloc] initWithFrame:CGRectMake(90, 55, 320, 50)];
    }
    stopWatchLabel.textColor = [UIColor colorWithRed:([[_textColor objectAtIndex:0]intValue]/255.f) green:([[_textColor objectAtIndex:1]intValue]/255.f) blue:([[_textColor objectAtIndex:2]intValue]/255.f) alpha:1.0f];
    labelText = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%02d%@%02d%@%02d",currentHours,@":",currentMinutes,@":",currentSeconds]];
    [labelText addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue-UltraLight" size:_textSize] range:NSMakeRange(0,5)];
    [labelText addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue-UltraLight" size:(_textSize-10)] range:NSMakeRange(5, 3)];
    stopWatchLabel.attributedText = labelText;
    if (initialize)
    {
        [self addSubview:stopWatchLabel];
    }
    
}
- (void)resetTimer:(BOOL)initializeLabel
{
    timerStop = true;
    currentHours = 0;
    currentMinutes = 0;
    currentSeconds = 0;
    [self displayText:initializeLabel];
    [self displayCircles:false];
}
-(void)setDefaultValues
{
    foreGroundAnimationStop = true;
    _textSize = [[_konyEnv.model valueForKey:@"textSize"]intValue];
    
    if(_textSize > 35)
    {
        _textSize = 35;
    }
    else if(_textSize < 0 )
    {
        _textSize = 0;
    }
    
    _bgTransparancy = [[_konyEnv.model valueForKey:@"bgTransparancy"]floatValue];
    
    if(_bgTransparancy <= 0.0f)
    {
        _bgTransparancy = 1.0f;
    }
    else if (_bgTransparancy > 100.0f)
    {
        _bgTransparancy = 0.0f;
    }
    else
    {
        _bgTransparancy = 1.0f-(_bgTransparancy/100.0f);
    }
    
    _textColor = [[NSMutableArray alloc]initWithObjects:@38,@171,@226,nil];
    _fgCircleColor = [[NSMutableArray alloc]initWithObjects:@0,@0,@0,nil];
    _bgCircleColor = [[NSMutableArray alloc]initWithObjects:@155,@155,@155,nil];
    _bgColor = [[NSMutableArray alloc]initWithObjects: @255, @255, @255, nil];
    
    [self resetTimer:true];
   
    self.backgroundColor = [UIColor clearColor];
}

# pragma mark Initialize the custom widget

- (id)initWithFrame:(CGRect) frame
{
    self = [super initWithFrame:frame];
    return self;
}

- (id)initWithEventDelegate:(id) eventDelegate withKonyEnvironment:(id) env
{
    self = [self init];
    _stopWatchProtocol = eventDelegate;
    _konyEnv = (KonyCWIEnvironment*) env;
    [self setDefaultValues];    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(onTap)];
    tapGesture.numberOfTapsRequired = 1;
    [self addGestureRecognizer:tapGesture];
    return self;
}

# pragma mark Model update related

- (void) modelUpdatedForProperty:(NSString*) propertyName  withOldValue:(id) oValue newValue:(id) nValue
{
    if (timerStop == true)
    {
        currentHours = 0;
        currentMinutes = 0;
        currentSeconds = 0;
    }
    if ([propertyName isEqualToString:@"textSize"])
    {
        _textSize = [nValue intValue];
        if(_textSize > 35)
        {
            _textSize = 35;
        }
        else if(_textSize < 0 )
        {
            _textSize = 0;
        }
        labelText = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%02d%@%02d%@%02d",currentHours,@":",currentMinutes,@":",currentSeconds]];
        [labelText addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue-UltraLight" size:_textSize] range:NSMakeRange(0,5)];
        [labelText addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue-UltraLight" size:(_textSize-10)] range:NSMakeRange(5, 3)];
        stopWatchLabel.attributedText = labelText;
        [stopWatchLabel setHidden:false];
    }
    else if([propertyName isEqualToString:@"textColor"])
    {
        _textColor = nValue;
        for (int i=0 ; i<3 ;i++)
        {
            id object = [_textColor objectAtIndex:i];
            if([object intValue] > 255)
            {
                [_textColor setObject:@255 atIndexedSubscript:i];
                
            }
            else if([object intValue] < 0)
            {
                [_textColor setObject:@0 atIndexedSubscript:i];
            }
        }
        stopWatchLabel.textColor = [UIColor colorWithRed:([[_textColor objectAtIndex:0]intValue]/255.f) green:([[_textColor objectAtIndex:1]intValue]/255.f) blue:([[_textColor objectAtIndex:2]intValue]/255.f) alpha:1.0f];
    }
    else if([propertyName isEqualToString:@"bgColor"])
    {
        _bgColor = nValue;
        for (int i=0 ; i<3 ;i++)
        {
            id object = [_bgColor objectAtIndex:i];
            if([object intValue] > 255)
            {
                [_bgColor setObject:@255 atIndexedSubscript:i];
                
            }
            else if([object intValue] < 0)
            {
                [_bgColor setObject:@0 atIndexedSubscript:i];
            }
        }
        self.backgroundColor = [UIColor colorWithRed:([[_bgColor objectAtIndex:0]intValue]/255.f) green:([[_bgColor objectAtIndex:1]intValue]/255.f) blue:([[_bgColor objectAtIndex:2]intValue]/255.f) alpha:_bgTransparancy];
        
    }
    else if ([propertyName isEqualToString:@"bgTransparancy"])
    {
        _bgTransparancy = [nValue floatValue];
        if(_bgTransparancy <= 0.0f)
        {
            _bgTransparancy = 1.0f;
        }
        else if (_bgTransparancy > 100.0f)
        {
            _bgTransparancy = 0.0f;
        }
        else
        {
            _bgTransparancy = 1.0f-(_bgTransparancy/100.0f);
        }
        self.alpha = _bgTransparancy;
    }
    else if([propertyName isEqualToString:@"foregroundCircleColor"])
    {
        _fgCircleColor = nValue;
        
        for (int i=0 ; i<3 ;i++)
        {
            id object = [_fgCircleColor objectAtIndex:i];
            if([object intValue] > 255)
            {
                [_fgCircleColor setObject:@255 atIndexedSubscript:i];
                
            }
            else if([object intValue] < 0)
            {
                [_fgCircleColor setObject:@0 atIndexedSubscript:i];
            }
        }
        blackCircle.strokeColor = [UIColor colorWithRed:([[_fgCircleColor objectAtIndex:0]intValue]/255.f) green:([[_fgCircleColor objectAtIndex:1]intValue]/255.f) blue:([[_fgCircleColor objectAtIndex:2]intValue]/255.f) alpha:1.0f].CGColor;
        
    }
    else if([propertyName isEqualToString:@"backgroundCircleColor"])
    {
        _bgCircleColor = nValue;
        for (int i=0 ; i<3 ;i++)
        {
            id object = [_bgCircleColor objectAtIndex:i];
            if([object intValue] > 255)
            {
                [_bgCircleColor setObject:@255 atIndexedSubscript:i];
                
            }
            else if([object intValue] < 0)
            {
                [_bgCircleColor setObject:@0 atIndexedSubscript:i];
            }
        }
        grayCircle.strokeColor = [UIColor colorWithRed:([[_bgCircleColor objectAtIndex:0]intValue]/255.f) green:([[_bgCircleColor objectAtIndex:1]intValue]/255.f) blue:([[_bgCircleColor objectAtIndex:2]intValue]/255.f) alpha:1.0f].CGColor;        
    }

}


# pragma mark View releated methods

- (UIView*) getWidgetView
{
    return self;
}

- (CGSize) getPreferredSizeForGivenSize: (CGSize) givenSize
{
    CGSize preferredSize = givenSize;
    preferredSize.height = (2*radius)+20;
    return preferredSize;
}

- (void) setWidgetViewFrame: (CGRect) frame
{
    self.frame = frame;
    self.clipsToBounds = true;
}

# pragma mark Event handling

- (void)onTap
{
    [_stopWatchProtocol onClick];
}


@end
